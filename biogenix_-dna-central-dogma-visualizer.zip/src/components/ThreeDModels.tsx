import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Float, Line, Sphere, Tube, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';

interface DNABaseProps {
  position: [number, number, number];
  type: 'A' | 'T' | 'G' | 'C' | 'U';
}

const BaseColors = {
  A: '#ef4444', // Red
  T: '#3b82f6', // Blue
  G: '#10b981', // Green
  C: '#f59e0b', // Yellow
  U: '#ec4899', // Pink
};

export function Base({ position, type }: DNABaseProps) {
  return (
    <Sphere args={[0.3, 16, 16]} position={position}>
      <meshStandardMaterial color={BaseColors[type]} emissive={BaseColors[type]} emissiveIntensity={0.5} />
    </Sphere>
  );
}

export function HelixStrand({ 
  sequence, 
  offset = 0, 
  color = "#555", 
  twist = 1,
  visibleLength,
  detachmentFactor = 0
}: { 
  sequence: string, 
  offset?: number, 
  color?: string, 
  twist?: number,
  visibleLength?: number,
  detachmentFactor?: number
}) {
  const currentSeq = visibleLength !== undefined ? sequence.slice(0, Math.ceil(visibleLength)) : sequence;
  
  const points = useMemo(() => {
    const pts = [];
    const radius = 2 + (detachmentFactor * 4); // Push away based on detachment
    const heightPerBase = 1.2;
    const totalLength = sequence.length;
    
    for (let i = 0; i < currentSeq.length; i++) {
      const angle = i * twist + offset + (detachmentFactor * Math.PI * 0.2); // Also twist slightly when detaching
      pts.push(new THREE.Vector3(
        Math.cos(angle) * radius,
        i * heightPerBase - (totalLength * heightPerBase) / 2,
        Math.sin(angle) * radius
      ));
    }
    
    // Ensure at least 2 points for curve
    if (pts.length < 2) {
      pts.push(new THREE.Vector3(0, - (totalLength * heightPerBase) / 2, 0));
      if (pts.length < 2) pts.push(new THREE.Vector3(0, - (totalLength * heightPerBase) / 2 + 0.1, 0));
    }
    
    return pts;
  }, [currentSeq, offset, twist, detachmentFactor, sequence.length]);

  const curve = useMemo(() => new THREE.CatmullRomCurve3(points), [points]);

  return (
    <group>
      <Tube args={[curve, 64, 0.1, 8, false]}>
        <meshStandardMaterial color={color} transparent opacity={0.8} />
      </Tube>
      {currentSeq.split('').map((base, i) => (
        <Base key={i} position={[points[i].x, points[i].y, points[i].z]} type={base as any} />
      ))}
    </group>
  );
}

export function ProteinChain({ points, aminoAcids }: { points: [number, number, number][], aminoAcids: { symbol: string }[] }) {
  const curvePoints = useMemo(() => points.map(p => new THREE.Vector3(...p)), [points]);
  const curve = useMemo(() => new THREE.CatmullRomCurve3(curvePoints), [curvePoints]);

  return (
    <group>
      <Tube args={[curve, 100, 0.2, 8, false]}>
        <MeshDistortMaterial color="#3b82f6" speed={1} distort={0.2} radius={1} />
      </Tube>
      {curvePoints.map((pt, i) => (
        <Sphere key={i} args={[0.5, 16, 16]} position={pt}>
          <meshStandardMaterial 
            color={aminoAcids[i] ? '#10b981' : '#555'} 
            emissive={aminoAcids[i] ? '#10b981' : '#555'} 
            emissiveIntensity={0.2} 
          />
        </Sphere>
      ))}
    </group>
  );
}

export function RotatingGroup({ children }: { children: React.ReactNode }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y += 0.005;
    }
  });
  return <group ref={ref}>{children}</group>;
}
