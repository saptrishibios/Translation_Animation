/**
 * Biological utilities for DNA processing
 */

export const DNA_BASES = ['A', 'T', 'G', 'C'] as const;
export const RNA_BASES = ['A', 'U', 'G', 'C'] as const;

export type DNABase = typeof DNA_BASES[number];
export type RNABase = typeof RNA_BASES[number];

/**
 * Validates a DNA sequence
 */
export function validateDNA(sequence: string): boolean {
  const upper = sequence.toUpperCase();
  return /^[ATGC\n\r ]+$/.test(upper);
}

/**
 * Transcribes DNA to mRNA
 * A -> U
 * T -> A
 * G -> C
 * C -> G
 */
export function transcribe(dna: string): string {
  return dna
    .toUpperCase()
    .replace(/\s/g, '')
    .split('')
    .map(base => {
      switch (base) {
        case 'A': return 'U';
        case 'T': return 'A';
        case 'G': return 'C';
        case 'C': return 'G';
        default: return '';
      }
    })
    .join('');
}

/**
 * Codon Table (simplified)
 */
export const CODON_TABLE: Record<string, { aminoAcid: string; name: string; symbol: string }> = {
  "AUG": { aminoAcid: "M", name: "Methionine", symbol: "Met" },
  "UUU": { aminoAcid: "F", name: "Phenylalanine", symbol: "Phe" },
  "UUC": { aminoAcid: "F", name: "Phenylalanine", symbol: "Phe" },
  "UUA": { aminoAcid: "L", name: "Leucine", symbol: "Leu" },
  "UUG": { aminoAcid: "L", name: "Leucine", symbol: "Leu" },
  "UCU": { aminoAcid: "S", name: "Serine", symbol: "Ser" },
  "UCC": { aminoAcid: "S", name: "Serine", symbol: "Ser" },
  "UCA": { aminoAcid: "S", name: "Serine", symbol: "Ser" },
  "UCG": { aminoAcid: "S", name: "Serine", symbol: "Ser" },
  "UAU": { aminoAcid: "Y", name: "Tyrosine", symbol: "Tyr" },
  "UAC": { aminoAcid: "Y", name: "Tyrosine", symbol: "Tyr" },
  "UGU": { aminoAcid: "C", name: "Cysteine", symbol: "Cys" },
  "UGC": { aminoAcid: "C", name: "Cysteine", symbol: "Cys" },
  "UGG": { aminoAcid: "W", name: "Tryptophan", symbol: "Trp" },
  "CUU": { aminoAcid: "L", name: "Leucine", symbol: "Leu" },
  "CUC": { aminoAcid: "L", name: "Leucine", symbol: "Leu" },
  "CUA": { aminoAcid: "L", name: "Leucine", symbol: "Leu" },
  "CUG": { aminoAcid: "L", name: "Leucine", symbol: "Leu" },
  "CCU": { aminoAcid: "P", name: "Proline", symbol: "Pro" },
  "CCC": { aminoAcid: "P", name: "Proline", symbol: "Pro" },
  "CCA": { aminoAcid: "P", name: "Proline", symbol: "Pro" },
  "CCG": { aminoAcid: "P", name: "Proline", symbol: "Pro" },
  "CAU": { aminoAcid: "H", name: "Histidine", symbol: "His" },
  "CAC": { aminoAcid: "H", name: "Histidine", symbol: "His" },
  "CAA": { aminoAcid: "Q", name: "Glutamine", symbol: "Gln" },
  "CAG": { aminoAcid: "Q", name: "Glutamine", symbol: "Gln" },
  "CGU": { aminoAcid: "R", name: "Arginine", symbol: "Arg" },
  "CGC": { aminoAcid: "R", name: "Arginine", symbol: "Arg" },
  "CGA": { aminoAcid: "R", name: "Arginine", symbol: "Arg" },
  "CGG": { aminoAcid: "R", name: "Arginine", symbol: "Arg" },
  "AUU": { aminoAcid: "I", name: "Isoleucine", symbol: "Ile" },
  "AUC": { aminoAcid: "I", name: "Isoleucine", symbol: "Ile" },
  "AUA": { aminoAcid: "I", name: "Isoleucine", symbol: "Ile" },
  "ACU": { aminoAcid: "T", name: "Threonine", symbol: "Thr" },
  "ACC": { aminoAcid: "T", name: "Threonine", symbol: "Thr" },
  "ACA": { aminoAcid: "T", name: "Threonine", symbol: "Thr" },
  "ACG": { aminoAcid: "T", name: "Threonine", symbol: "Thr" },
  "AAU": { aminoAcid: "N", name: "Asparagine", symbol: "Asn" },
  "AAC": { aminoAcid: "N", name: "Asparagine", symbol: "Asn" },
  "AAA": { aminoAcid: "K", name: "Lysine", symbol: "Lys" },
  "AAG": { aminoAcid: "K", name: "Lysine", symbol: "Lys" },
  "AGU": { aminoAcid: "S", name: "Serine", symbol: "Ser" },
  "AGC": { aminoAcid: "S", name: "Serine", symbol: "Ser" },
  "AGA": { aminoAcid: "R", name: "Arginine", symbol: "Arg" },
  "AGG": { aminoAcid: "R", name: "Arginine", symbol: "Arg" },
  "GUU": { aminoAcid: "V", name: "Valine", symbol: "Val" },
  "GUC": { aminoAcid: "V", name: "Valine", symbol: "Val" },
  "GUA": { aminoAcid: "V", name: "Valine", symbol: "Val" },
  "GUG": { aminoAcid: "V", name: "Valine", symbol: "Val" },
  "GCU": { aminoAcid: "A", name: "Alanine", symbol: "Ala" },
  "GCC": { aminoAcid: "A", name: "Alanine", symbol: "Ala" },
  "GCA": { aminoAcid: "A", name: "Alanine", symbol: "Ala" },
  "GCG": { aminoAcid: "A", name: "Alanine", symbol: "Ala" },
  "GAU": { aminoAcid: "D", name: "Aspartic Acid", symbol: "Asp" },
  "GAC": { aminoAcid: "D", name: "Aspartic Acid", symbol: "Asp" },
  "GAA": { aminoAcid: "E", name: "Glutamic Acid", symbol: "Glu" },
  "GAG": { aminoAcid: "E", name: "Glutamic Acid", symbol: "Glu" },
  "GGU": { aminoAcid: "G", name: "Glycine", symbol: "Gly" },
  "GGC": { aminoAcid: "G", name: "Glycine", symbol: "Gly" },
  "GGA": { aminoAcid: "G", name: "Glycine", symbol: "Gly" },
  "GGG": { aminoAcid: "G", name: "Glycine", symbol: "Gly" },
  "UAA": { aminoAcid: "_", name: "STOP", symbol: "STP" },
  "UAG": { aminoAcid: "_", name: "STOP", symbol: "STP" },
  "UGA": { aminoAcid: "_", name: "STOP", symbol: "STP" },
};

/**
 * Translates mRNA to Amino Acid chain
 */
export function translate(mrna: string): { aminoAcid: string; name: string; symbol: string }[] {
  const result = [];
  for (let i = 0; i <= mrna.length - 3; i += 3) {
    const codon = mrna.substring(i, i + 3);
    const aa = CODON_TABLE[codon];
    if (aa) {
      result.push(aa);
      if (aa.aminoAcid === '_') break; // STOP codon
    }
  }
  return result;
}

/**
 * Generates a simple 3D path for a protein fold based on sequence
 * This is a deterministic but pseudo-random fold for visualization purposes.
 */
export function generateProteinPath(length: number): [number, number, number][] {
  const points: [number, number, number][] = [[0, 0, 0]];
  let current: [number, number, number] = [0, 0, 0];
  
  for (let i = 1; i < length; i++) {
    // Determine next direction with some "folding" logic
    // We want it to stay somewhat compact
    const theta = (i * 1.5) % (Math.PI * 2);
    const phi = (i * 0.8) % Math.PI;
    const r = 2;
    
    current = [
      current[0] + r * Math.sin(phi) * Math.cos(theta),
      current[1] + r * Math.sin(phi) * Math.sin(theta),
      current[2] + r * Math.cos(phi)
    ];
    
    points.push([...current]);
  }
  
  return points;
}
