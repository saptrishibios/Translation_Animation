/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Stars, Center, Text } from '@react-three/drei';
import { 
  Dna, 
  ArrowRight, 
  Play, 
  RotateCcw, 
  Microscope, 
  Info, 
  FlaskConical,
  Activity,
  Zap
} from 'lucide-react';
import { transcribe, translate, validateDNA, generateProteinPath } from './lib/bio-utils';
import { HelixStrand, RotatingGroup, ProteinChain } from './components/ThreeDModels';
import { cn } from './lib/utils';
import { GoogleGenAI } from "@google/genai";

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

type Stage = 'INPUT' | 'PCR' | 'TRANSCRIPTION' | 'TRANSLATION' | 'REPORT';

export default function App() {
  const [dnaSeq, setDnaSeq] = useState('ATGCATGCATGC');
  const [stage, setStage] = useState<Stage>('INPUT');
  const [mrnaSeq, setMrnaSeq] = useState('');
  const [protein, setProtein] = useState<{ aminoAcid: string; name: string; symbol: string }[]>([]);
  const [pcrCount, setPcrCount] = useState(1);
  const [transcriptionProgress, setTranscriptionProgress] = useState(0);
  const [aiReport, setAiReport] = useState('');
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);

  const proteinPath = useMemo(() => generateProteinPath(protein.length), [protein]);

  const handleStart = () => {
    if (!validateDNA(dnaSeq)) {
      alert("Invalid DNA sequence. Use only A, T, G, C.");
      return;
    }
    setStage('PCR');
  };

  const handleTranscribe = () => {
    const rna = transcribe(dnaSeq);
    setMrnaSeq(rna);
    setTranscriptionProgress(0);
    setStage('TRANSCRIPTION');
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (stage === 'TRANSCRIPTION' && transcriptionProgress < mrnaSeq.length) {
      interval = setInterval(() => {
        setTranscriptionProgress(prev => Math.min(prev + 0.5, mrnaSeq.length));
      }, 50);
    }
    return () => clearInterval(interval);
  }, [stage, transcriptionProgress, mrnaSeq.length]);

  const handleTranslate = () => {
    const aa = translate(mrnaSeq);
    setProtein(aa);
    setStage('TRANSLATION');
  };

  const reset = () => {
    setStage('INPUT');
    setMrnaSeq('');
    setProtein([]);
    setPcrCount(1);
    setTranscriptionProgress(0);
    setAiReport('');
  };

  const generateAIAnalysis = async () => {
    setIsGeneratingReport(true);
    try {
      const response = await genAI.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Act as a molecular bio-informatician. Given the DNA sequence "${dnaSeq}", it transcribes to mRNA "${mrnaSeq}" and translates to the protein sequence "${protein.map(p => p.aminoAcid).join('')}". 
        Briefly describe the potential function, stability, and hydrophobicity of this hypothetical peptide. Keep it scientific but accessible. Format in 3 short bullet points.`,
      });
      
      setAiReport(response.text || "Report generated but empty.");
    } catch (error) {
      console.error(error);
      setAiReport("Unable to generate biochemical report. Analysis failed.");
    } finally {
      setIsGeneratingReport(false);
    }
  };

  useEffect(() => {
    if (stage === 'TRANSLATION' && protein.length > 0 && !aiReport) {
      generateAIAnalysis();
    }
  }, [stage, protein]);

  return (
    <div className="min-h-screen scientific-grid relative text-white selection:bg-blue-500/30">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-600/10 rounded-full blur-[120px]" />
      </div>

      {/* Header */}
      <header className="relative z-20 border-b border-white/10 glass flex items-center justify-between px-8 py-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Dna className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">BIOGENIX</h1>
            <p className="text-[10px] uppercase tracking-widest text-white/40 font-mono">Central Dogma Simulation v2.0</p>
          </div>
        </div>

        <div className="flex gap-4">
          <StageIndicator current={stage} />
        </div>
      </header>

      <main className="relative z-10 grid grid-cols-1 lg:grid-cols-12 min-h-[calc(100vh-73px)]">
        {/* Left Panel: Controls & Info */}
        <aside className="lg:col-span-4 border-r border-white/10 p-8 flex flex-col gap-6 overflow-y-auto max-h-[calc(100vh-73px)]">
          <AnimatePresence mode="wait">
            {stage === 'INPUT' ? (
              <motion.div 
                key="input"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-3xl font-display italic text-white/90">Entry Protocol</h2>
                  <p className="text-white/50 mt-2 text-sm">Sequence input required for molecular synthesis.</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">DNA Sequence (ATGC)</label>
                  <textarea 
                    value={dnaSeq}
                    onChange={(e) => setDnaSeq(e.target.value.toUpperCase())}
                    className="w-full h-40 bg-white/5 border border-white/10 rounded-xl p-4 font-mono text-xl focus:outline-none focus:border-blue-500 transition-colors resize-none uppercase"
                    placeholder="Enter ATGC sequence..."
                  />
                  <div className="flex justify-between items-center text-[10px] font-mono text-white/30">
                    <span>LENGTH: {dnaSeq.length} BP</span>
                    <span>TYPE: GENOMIC DNA</span>
                  </div>
                </div>

                <button 
                  onClick={handleStart}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-600/20 transition-all flex items-center justify-center gap-2 group"
                >
                  INITIALIZE SYNTHESIS
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>

                <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex gap-4">
                  <Info className="w-5 h-5 text-blue-400 shrink-0" />
                  <p className="text-xs text-white/60 leading-relaxed">
                    DNA sequences represent the genetic blueprint. Our simulator will amplify this sequence via PCR before initiating transcription.
                  </p>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="active"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-display italic text-white/90">Synthesis Active</h2>
                    <p className="text-white/50 text-xs mt-1">Current State: {stage}</p>
                  </div>
                  <button onClick={reset} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                    <RotateCcw className="w-5 h-5 text-white/40" />
                  </button>
                </div>

                {stage === 'PCR' && (
                  <div className="space-y-4">
                    <div className="p-6 rounded-2xl bg-blue-500/10 border border-blue-500/20 glow-blue">
                      <div className="flex items-center gap-3 mb-4">
                        <Activity className="text-blue-400" />
                        <h3 className="font-bold text-blue-400 uppercase tracking-wider text-sm">Thermal Cycler</h3>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-white/40 text-[10px]">AMPLIFICATION CYCLE</span>
                          <span className="text-blue-400">2^{pcrCount} COPIES</span>
                        </div>
                        <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                          <motion.div 
                            className="bg-blue-500 h-full"
                            animate={{ width: `${(pcrCount / 10) * 100}%` }}
                            transition={{ duration: 1 }}
                          />
                        </div>
                      </div>
                      <button 
                        onClick={() => setPcrCount(c => Math.min(c + 1, 10))}
                        className="mt-6 w-full py-2 bg-blue-600/20 text-blue-400 border border-blue-500/30 rounded-lg text-xs font-bold hover:bg-blue-600/30 transition-colors"
                      >
                        RUN NEXT CYCLE
                      </button>
                    </div>

                    <button 
                      onClick={handleTranscribe}
                      className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                    >
                      <FlaskConical className="w-5 h-5" />
                      INITIATE TRANSCRIPTION
                    </button>
                  </div>
                )}

                {stage === 'TRANSCRIPTION' && (
                  <div className="space-y-4">
                    <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 glow-green">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="font-bold text-emerald-400 uppercase tracking-wider text-xs">mRNA Synthesis</h3>
                        <span className="text-[10px] font-mono text-emerald-400">
                          {Math.floor((transcriptionProgress / mrnaSeq.length) * 100)}%
                        </span>
                      </div>
                      <div className="bg-black/40 p-4 rounded-xl font-mono text-emerald-400 break-all text-sm h-32 overflow-y-auto uppercase relative group">
                        <div className="absolute inset-0 bg-emerald-500/5 animate-pulse group-hover:bg-transparent pointer-events-none transition-colors" />
                        {mrnaSeq.slice(0, Math.ceil(transcriptionProgress))}
                        <span className="animate-pulse">_</span>
                      </div>
                    </div>
                    <button 
                      onClick={handleTranslate}
                      disabled={transcriptionProgress < mrnaSeq.length}
                      className={cn(
                        "w-full py-4 font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2",
                        transcriptionProgress < mrnaSeq.length 
                          ? "bg-white/5 text-white/20 cursor-not-allowed border border-white/10" 
                          : "bg-pink-600 hover:bg-pink-500 text-white"
                      )}
                    >
                      <Zap className="w-5 h-5" />
                      COMPLETE TRANSLATION
                    </button>
                  </div>
                )}

                {stage === 'TRANSLATION' && (
                  <div className="space-y-4">
                    <div className="p-6 rounded-2xl bg-pink-500/10 border border-pink-500/20">
                      <h3 className="font-bold text-pink-400 uppercase tracking-wider text-xs mb-4">Peptide Analysis</h3>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {protein.map((aa, i) => (
                          <div key={i} className="px-2 py-1 bg-white/5 border border-white/10 rounded text-[10px] font-mono text-white/60">
                            {aa.symbol}
                          </div>
                        ))}
                      </div>
                      
                      <div className="mt-6 border-t border-white/10 pt-4">
                        <h4 className="text-[10px] text-white/40 uppercase mb-2">Molecular Report (AI Predicted)</h4>
                        {isGeneratingReport ? (
                          <div className="flex items-center gap-2 text-white/40 text-xs">
                            <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }}><RotateCcw className="w-3 h-3" /></motion.div>
                            Processing molecular data...
                          </div>
                        ) : (
                          <div className="text-xs text-white/70 leading-relaxed font-serif italic whitespace-pre-line">
                            {aiReport}
                          </div>
                        )}
                      </div>
                    </div>
                    <button onClick={reset} className="w-full py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl transition-all">
                      NEW SEQUENCE
                    </button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </aside>

        {/* Right Panel: 3D Visualization */}
        <section className="lg:col-span-8 relative bg-black/40 backdrop-blur-sm overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Canvas shadows gl={{ antialias: true }}>
              <PerspectiveCamera makeDefault position={[0, 5, 25]} fov={50} />
              <OrbitControls enableDamping dampingFactor={0.05} autoRotate={stage === 'INPUT'} autoRotateSpeed={0.5} />
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} intensity={1} color="#3b82f6" />
              <pointLight position={[-10, -10, -10]} intensity={0.5} color="#10b981" />
              <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
              
              <Center>
                <RotatingGroup>
                  {stage === 'INPUT' && (
                    <HelixStrand sequence="ATGCATGCATGCATGC" offset={0} color="#3b82f6" twist={0.5} />
                  )}
                  {stage === 'PCR' && (
                    <>
                      <HelixStrand sequence={dnaSeq} offset={0} color="#3b82f6" twist={0.3} />
                      {pcrCount > 1 && (
                         <HelixStrand sequence={dnaSeq} offset={Math.PI} color="#3b82f6" twist={0.3} />
                      )}
                    </>
                  )}
                  {stage === 'TRANSCRIPTION' && (
                    <>
                      <HelixStrand sequence={dnaSeq} offset={0} color="#3b82f6" twist={0.3} />
                      <group position={[0, Math.sin(transcriptionProgress * 0.1) * 0.5, 0]}>
                        <HelixStrand 
                          sequence={mrnaSeq} 
                          offset={Math.PI / 2} 
                          color="#ec4899" 
                          twist={0.3} 
                          visibleLength={transcriptionProgress}
                          detachmentFactor={Math.min(transcriptionProgress / mrnaSeq.length, 1) * 0.5}
                        />
                      </group>
                    </>
                  )}
                  {stage === 'TRANSLATION' && (
                    <ProteinChain points={proteinPath} aminoAcids={protein} />
                  )}
                </RotatingGroup>
              </Center>
            </Canvas>
          </div>

          {/* Overlay Stats */}
          <div className="absolute bottom-8 left-8 right-8 flex justify-between items-end pointer-events-none">
            <div className="glass px-6 py-4 rounded-2xl flex gap-8 border-white/5">
              <Stat value={dnaSeq.length} label="Base Pairs" />
              {mrnaSeq && <Stat value={mrnaSeq.length} label="RNA Length" color="text-pink-400" />}
              {protein.length > 0 && <Stat value={protein.length} label="Amino Acids" color="text-emerald-400" />}
            </div>
            
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center bg-black/40">
                <Microscope className="w-5 h-5 text-white/40" />
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function Stat({ value, label, color = "text-blue-400" }: { value: number | string, label: string, color?: string }) {
  return (
    <div className="flex flex-col">
      <span className={cn("text-2xl font-bold font-mono tracking-tighter", color)}>{value}</span>
      <span className="text-[9px] uppercase tracking-widest text-white/30 font-bold">{label}</span>
    </div>
  );
}

function StageIndicator({ current }: { current: Stage }) {
  const steps: Stage[] = ['INPUT', 'PCR', 'TRANSCRIPTION', 'TRANSLATION'];
  const currentIndex = steps.indexOf(current === 'REPORT' ? 'TRANSLATION' : current);

  return (
    <div className="flex items-center gap-1">
      {steps.map((s, i) => (
        <React.Fragment key={s}>
          <div 
            className={cn(
              "w-2 h-2 rounded-full transition-all duration-500",
              i <= currentIndex ? "bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]" : "bg-white/10"
            )} 
          />
          {i < steps.length - 1 && <div className={cn("w-4 h-[1px]", i < currentIndex ? "bg-blue-500/40" : "bg-white/5")} />}
        </React.Fragment>
      ))}
    </div>
  );
}
